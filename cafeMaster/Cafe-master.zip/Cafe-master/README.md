# Café App

Café app for coffee shop management

### Prerequisites

```
Android Studio
```

### Installing

```
Clone this repo
Open with Android Studio
Run in device or emulator
```



## Built With

* [Android Studio](https://developer.android.com/studio/index.html) - Android Development IDE



