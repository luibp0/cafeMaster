package com.example.cafe;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cafe.helper.DatabaseHelper;
import com.example.cafe.model.User;

public class SignUpActivity extends AppCompatActivity {

    private String TAG = "LOGTAG";
    private DatabaseHelper databaseHelper;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        databaseHelper = new DatabaseHelper(this);
    }

    public void onClickSignUp(View view) {
        EditText emailEditText = findViewById(R.id.email_edit_text);
        EditText passwordEditText = findViewById(R.id.password_edit_text);
        EditText nameEditText = findViewById(R.id.name_edit_text);

        user = new User();
        user.setName(nameEditText.getText().toString());
        user.setEmail(emailEditText.getText().toString());
        user.setPassword(passwordEditText.getText().toString());

        signUpUser();
    }

    private void signUpUser() {
        if (databaseHelper.insertUser(user)) {
            Toast.makeText(getApplicationContext(), "Sign up success!", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.putExtra("User", user.getId());
            startActivity(intent);
            finish();
        } else {
            Toast.makeText(getApplicationContext(), "Sign up failed!", Toast.LENGTH_SHORT).show();
        }
    }


}
