package com.example.cafe;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cafe.helper.DatabaseHelper;


public class LoginActivity extends AppCompatActivity {

    private String TAG = "LOGTAG";
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // Initialize the database helper
        databaseHelper = new DatabaseHelper(this);
    }

    public void onClickOpenSignUp(View view) {
        startActivity(new Intent(getApplicationContext(), SignUpActivity.class));
    }

    public void onClickLogin(View view) {
        EditText emailEditText = findViewById(R.id.email_edit_text_log);
        EditText passwordEditText = findViewById(R.id.password_edit_text_log);
        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();

        // Perform database query to check if the email and password are valid
        boolean isValid = databaseHelper.checkUserCredentials(email, password);

        if (isValid) {
            // Login successful
            Log.d(TAG, "signInWithEmail:successful");
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            intent.putExtra("User", email); // Use the email as the user identifier
            startActivity(new Intent(getApplicationContext(), OrderActivity.class));
            finish();
        } else {
            // Login failed
            Log.w(TAG, "signInWithEmail:failed");
            Toast.makeText(getApplicationContext(), R.string.auth_failed, Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close the database helper
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }

}
