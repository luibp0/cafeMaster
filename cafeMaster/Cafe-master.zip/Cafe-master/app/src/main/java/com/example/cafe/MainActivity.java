package com.example.cafe;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.appcompat.app.AppCompatActivity;

import com.example.cafe.helper.DatabaseHelper;


public class MainActivity extends AppCompatActivity {

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String id = getIntent().getStringExtra("User");

        // Initialize the database helper
        databaseHelper = new DatabaseHelper(this);

        // Get a writable database
        SQLiteDatabase db = databaseHelper.getWritableDatabase();

        // Define the columns you want to retrieve
        String[] columns = {DatabaseHelper.COLUMN_ID, DatabaseHelper.COLUMN_EMAIL, DatabaseHelper.COLUMN_NAME};

        // Define the selection criteria
        String selection = DatabaseHelper.COLUMN_ID + " = ?";
        String[] selectionArgs = {id};

        // Query the database
        Cursor cursor = db.query(DatabaseHelper.TABLE_USERS, columns, selection, selectionArgs,
                null, null, null);

        SharedPreferences sharedPref = getApplicationContext().getSharedPreferences(
                getString(R.string.preference_file_key), Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        if (cursor != null && cursor.moveToFirst()) {
            // Retrieve the values from the cursor
            @SuppressLint("Range") String email = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_EMAIL));
            @SuppressLint("Range") String name = cursor.getString(cursor.getColumnIndex(DatabaseHelper.COLUMN_NAME));

            // Store the values in SharedPreferences
            editor.putString("id", id);
            editor.putString("email", email);
            editor.putString("name", name);
        }

        // Close the cursor and database
        if (cursor != null) {
            cursor.close();
        }
        db.close();

        editor.apply();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.action_exit:
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close the database helper
        if (databaseHelper != null) {
            databaseHelper.close();
        }
    }
}