package com.example.cafe;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.example.cafe.model.Product;

import java.util.ArrayList;
import java.util.Calendar;

public class OrderActivity extends AppCompatActivity {

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        if (item.getItemId() == R.id.action_exit) {
            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    Calendar calendar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        ArrayList<Product> products = new ArrayList<Product>();
        products.add(new Product("Cappuccino", R.drawable.cappuccino));
        products.add(new Product("Espresso", R.drawable.espresso));
        products.add(new Product("Naked", R.drawable.naked));
        products.add(new Product("Latte", R.drawable.latte));
        products.add(new Product("Chocolate", R.drawable.hot_chocolate));
        products.add(new Product("Mocha", R.drawable.mocha));
        products.add(new Product("Ristretto", R.drawable.ristretto));

        ProductAdapter productAdapter = new ProductAdapter(this, products);
        ListView orderList = (ListView) findViewById(R.id.order_list_view);
        orderList.setAdapter(productAdapter);

        orderList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, final View view, final int position, long id) {
                AlertDialog.Builder builder = new AlertDialog.Builder(OrderActivity.this);
                LayoutInflater inflater = getLayoutInflater();
                final View dialogView = inflater.inflate(R.layout.dialog_table, null);
                builder.setView(dialogView);

                builder.setPositiveButton(R.string.order, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getApplicationContext(), "Added", Toast.LENGTH_SHORT).show();

                    }
                });

                builder.setNegativeButton(R.string.cancel, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.cancel();
                    }
                });

                AlertDialog dialog = builder.create();
                dialog.show();

            }
        });

    }
}
